﻿namespace GetStoreAppInstaller.UI.Backdrop
{
    public enum EffectBorderMode
    {
        Soft = 0,
        Hard = 1
    }
}
