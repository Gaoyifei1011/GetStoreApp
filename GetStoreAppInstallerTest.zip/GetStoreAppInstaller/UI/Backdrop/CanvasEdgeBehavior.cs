﻿namespace GetStoreAppInstaller.UI.Backdrop
{
    public enum CanvasEdgeBehavior
    {
        Clamp = 0,
        Wrap = 1,
        Mirror = 2
    }
}
