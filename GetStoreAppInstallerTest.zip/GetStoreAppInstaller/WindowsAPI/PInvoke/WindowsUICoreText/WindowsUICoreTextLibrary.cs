﻿using System;
using System.Runtime.InteropServices;

namespace GetStoreAppInstaller.WindowsAPI.PInvoke.WindowsUICoreText
{
    /// <summary>
    /// windows.ui.core.textinput.dll 函数库
    /// </summary>
    public partial class WindowsUICoreTextLibrary
    {
        private const string WindowsUICoreText = "windows.ui.core.textinput.dll";

        [LibraryImport(WindowsUICoreText, EntryPoint = "#1500", SetLastError = false), PreserveSig]
        public static partial int CreateTextInputProducer(IntPtr consumer, out IntPtr pProducer);
    }
}
