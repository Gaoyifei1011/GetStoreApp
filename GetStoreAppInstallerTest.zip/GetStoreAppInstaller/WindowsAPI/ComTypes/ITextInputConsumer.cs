﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.Marshalling;
using WinRT;

namespace GetStoreAppInstaller.WindowsAPI.ComTypes
{
    [GeneratedComInterface, Guid("A9D00AB3-2FEF-41A0-B0AD-4B2129EA2663")]
    public partial interface ITextInputConsumer
    {
        /// <summary>
        /// 获取由当前Windows 运行时类实现的接口。
        /// </summary>
        /// <param name="iidCount">当前 Windows 运行时 对象实现的接口数，不包括 IUnknown 和 IInspectable 实现。</param>
        /// <param name="iids">指向数组的指针，该数组包含当前 Windows 运行时 对象实现的每个接口的 IID。 排除 IUnknown 和 IInspectable 接口。</param>
        /// <returns>此函数可以返回以下值。S_OK 和 E_OUTOFMEMORY</returns>
        [PreserveSig]
        int GetIids(out ulong iidCount, out IntPtr iids);

        /// <summary>
        /// 获取当前Windows 运行时 对象的完全限定名称。
        /// </summary>
        /// <param name="className">当前Windows 运行时对象的完全限定名称。</param>
        /// <returns>此函数可以返回以下值。S_OK、E_OUTOFMEMORY 和 E_ILLEGAL_METHOD_CALL</returns>
        [PreserveSig]
        int GetRuntimeClassName(out IntPtr className);

        /// <summary>
        /// 获取当前Windows 运行时对象的信任级别。
        /// </summary>
        /// <param name="trustLevel">当前Windows 运行时对象的信任级别。 默认值为 BaseLevel。</param>
        /// <returns>此方法始终返回 S_OK。</returns>
        [PreserveSig]
        int GetTrustLevel(out TrustLevel trustLevel);

        [PreserveSig]
        int GetTextInputProducer(out ITextInputProducer textInputProducer);

        [PreserveSig]
        int SetTextInputProducer(ITextInputProducer textInputProducer);

        [PreserveSig]
        int InvokeAcceleratorKeyEventHandlers();

        [PreserveSig]
        int InvokeKeyDownEventHandlers();

        int InvokeKeyUpEventHandlers();

        [PreserveSig]
        int InvokeCharacterReceivedEventHandlers();

        [PreserveSig]
        int InvokeSystemKeyDownEventHandlers();

        [PreserveSig]
        int InvokeSystemKeyUpEventHandlers();

        [PreserveSig]
        int InvokeNavigationFocusEventHandlers();

        [PreserveSig]
        int OnTextInputProducerFocusChanged();

        [PreserveSig]
        int OnEnableNonCUIDepartFocus();
    }
}
