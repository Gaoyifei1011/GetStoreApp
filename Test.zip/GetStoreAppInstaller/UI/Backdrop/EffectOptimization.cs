﻿namespace GetStoreAppInstaller.UI.Backdrop
{
    public enum EffectOptimization
    {
        Speed = 0,
        Balanced = 1,
        Quality = 2
    }
}
