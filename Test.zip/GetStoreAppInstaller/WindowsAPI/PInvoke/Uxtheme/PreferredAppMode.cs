﻿namespace GetStoreAppInstaller.WindowsAPI.PInvoke.Uxtheme
{
    /// <summary>
    /// 菜单主题样式
    /// </summary>
    public enum PreferredAppMode
    {
        Default,
        AllowDark,
        ForceDark,
        ForceLight,
        Max
    };
}
